package bd.edu.seu.bijoyfx;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class SecondSceneController implements Initializable {

    @FXML
    private TableColumn<DetailsTable, String> LastPurchaseColumn;

    @FXML
    private Label boostList;

    @FXML
    private TableColumn<DetailsTable, String> boostedColumn;

    @FXML
    private TableColumn<DetailsTable, String> colorColumn;

    @FXML
    private Label colorList;

    @FXML
    private Label customerList;

    @FXML
    private Label detailsList;

    @FXML
    private TableColumn<DetailsTable, String> nameColumn;

    @FXML
    private Label nameList;

    @FXML
    private TableColumn<DetailsTable, Number> priceColumn;

    @FXML
    private Label priceList;

    @FXML
    private Label purchaseList;

    @FXML
    private TableColumn<DetailsTable, Number> quantityColumn;

    @FXML
    private Label quantityList;

    @FXML
    private Label sizeList;

    @FXML
    private TableColumn<DetailsTable, String> typeColumn;

    @FXML
    private Label typeList;

    @FXML
    private TableView<DetailsTable> viewTable;

    @FXML
    private ImageView imageViewList;

    @FXML
    private Label couponField;
    private boolean couponView = false;

    @FXML
    private TextField searchList;

    @FXML
    private Button deleteButton;

    @FXML
    void searchEvent(ActionEvent event) {

        // for search button method
        String keyword = searchList.getText().trim().toLowerCase();

        if (keyword.isEmpty()) {
            // If empty, reset to full list
            viewTable.setItems(globalData.detailsTableObservableList);
            return;
        }

        ObservableList<DetailsTable> filteredList = FXCollections.observableArrayList();

        for (DetailsTable item : globalData.detailsTableObservableList) {
            if (item.getName().toLowerCase().contains(keyword) ||
                    item.getType().toLowerCase().contains(keyword) ||
                    item.getColor().toLowerCase().contains(keyword) ||
                    item.getSize().toLowerCase().contains(keyword) ||
                    item.getCustomer().toLowerCase().contains(keyword) ||
                    item.getCoupon().toLowerCase().contains(keyword)) {
                filteredList.add(item);
            }
        }

        viewTable.setItems(filteredList);
    }


    @FXML
    void backEvent(ActionEvent event) {
        HelloApplication.changeScene("first-scene");
    }

    @FXML
    void editEvent(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Edit Feature");
        alert.setHeaderText(null);
        alert.setContentText("Feature is coming soon.");
        alert.showAndWait();
    }

    @FXML
    void showCouponEvent(ActionEvent event) {
        couponView = !couponView;
        couponField.setVisible(couponView);
        couponField.managedProperty().bind(couponField.visibleProperty());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        globalData.detailsTableObservableList.clear(); // Clear previous data to avoid duplicates

        try {
            RandomAccessFile raf = new RandomAccessFile("dress.txt", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length >= 12) {
                    try {
                        String name = parts[0];
                        String type = parts[1];
                        String size = parts[2];
                        String color = parts[3];
                        double price = Double.parseDouble(parts[4]);
                        String details = parts[5];

                        String dateText = parts[6];
                        if (dateText == null || dateText.trim().equalsIgnoreCase("null") || dateText.trim().isEmpty()) {
                            System.out.println("Skipping due to invalid date: " + line);
                            continue;
                        }
                        LocalDate purchaseDate = LocalDate.parse(dateText);

                        int quantity = Integer.parseInt(parts[7]);
                        String coupon = parts[8];
                        String customer = parts[9];
                        boolean boosted = Boolean.parseBoolean(parts[10]);
                        String imagePath = parts[11];

                        DetailsTable detailsTable = new DetailsTable(name, type, color, price, purchaseDate,
                                quantity, boosted, size, details, customer, coupon, imagePath);

                        globalData.detailsTableObservableList.add(detailsTable);
                    } catch (Exception e) {
                        System.out.println("Skipping corrupted line: " + line);
                    }
                }
            }
            raf.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // TableView setup
        nameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        typeColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getType()));
        colorColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getColor()));
        priceColumn.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getPrice()));
        quantityColumn.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getQuantity()));
        LastPurchaseColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getLastPurchase().toString()));
        boostedColumn.setCellValueFactory(c -> new SimpleBooleanProperty(c.getValue().getBoosted()).asString());

        viewTable.setItems(globalData.detailsTableObservableList);

        // Show last entry
        if (!globalData.detailsTableObservableList.isEmpty()) {
            showDetails(globalData.detailsTableObservableList.get(globalData.detailsTableObservableList.size() - 1));
        }

        // Show selected row details
        viewTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                showDetails(newVal);
            }
        });

        // for coupon invisible before click show code
        couponField.setVisible(false);
        couponField.managedProperty().bind(couponField.visibleProperty());

        // for button disable
        deleteButton.setDisable(true);

    }

    //  Method to show selected item details in labels
    private void showDetails(DetailsTable selected) {
        nameList.setText(selected.getName());
        typeList.setText(selected.getType());
        colorList.setText(selected.getColor());
        priceList.setText(String.valueOf(selected.getPrice()));
        quantityList.setText(String.valueOf(selected.getQuantity()));
        purchaseList.setText(selected.getLastPurchase().toString());
        boostList.setText(String.valueOf(selected.getBoosted()));
        sizeList.setText(selected.getSize());
        detailsList.setText(selected.getDetails());
        customerList.setText(selected.getCustomer());
        couponField.setText(selected.getCoupon());

        //  Color is red when quantity is less than 10
        if (selected.getQuantity() < 10) {
            quantityList.setStyle("-fx-text-fill: red;");
        } else {
            quantityList.setStyle("-fx-text-fill: black;");
        }

        try {
            imageViewList.setImage(new Image(selected.getImagePath()));
        } catch (Exception e) {
            System.out.println("Image not loaded: " + e.getMessage());

        }
    }
}

package bd.edu.seu.bijoyfx;


import java.time.LocalDate;

public class DetailsTable {
    private String name;

    private String type;

    private String color;

    private double price;

    private LocalDate lastPurchase;

    private int quantity;

    private boolean boosted;

    private String size;

    private String details;

    private String customer;

    private String coupon;

    private String imagePath;



    public DetailsTable(String name, String type, String color, double price, LocalDate lastPurchase,
                        int quantity, boolean boosted, String size, String details, String customer, String coupon, String imagePath) {
        this.name = name;
        this.type = type;
        this.color = color;
        this.price = price;
        this.lastPurchase = lastPurchase;
        this.quantity = quantity;
        this.boosted = boosted;
        this.size = size;
        this.details = details;
        this.customer = customer;
        this.coupon = coupon;
        this.imagePath = imagePath;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public LocalDate getLastPurchase() {
        return lastPurchase;
    }

    public void setLastPurchase(LocalDate lastPurchase) {
        this.lastPurchase = lastPurchase;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean getBoosted() {
        return boosted;
    }

    public void setBoosted(boolean boosted) {
        this.boosted = boosted;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getCoupon() {
        return coupon;
    }

    public void setCoupon(String coupon) {
        this.coupon = coupon;
    }
    public String getImagePath() {
        return imagePath;
    }
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}


module bd.edu.seu.bijoyfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens bd.edu.seu.bijoyfx to javafx.fxml;
    exports bd.edu.seu.bijoyfx;
}
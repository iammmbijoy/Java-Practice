// this is first scene

package bd.edu.seu.bijoyfx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;

public class FirstSceneController implements Initializable {

    @FXML
    private CheckBox agreeCheckBox;

    @FXML
    private Label codeError;

    @FXML
    private Label colorError;

    @FXML
    private Label customerError;

    @FXML
    private Label dateError;

    @FXML
    private Label detailsError;

    @FXML
    private PasswordField discountField;

    @FXML
    private Set<String> usedDiscounts = new HashSet<>();

    @FXML
    private ColorPicker dressColorPicker;

    @FXML
    private Label dressNameError;

    @FXML
    private TextField dressNameField;

    @FXML
    private TextArea dressTextArea;

    @FXML
    private ChoiceBox<String> dressTypeChoiceBox;

    @FXML
    private Label dressTypeError;

    @FXML
    private ToggleGroup genderGroup;

    @FXML
    private ImageView imageView;
    @FXML
    private boolean isImageUploaded = false;
    private String lastUploadedImagePath = null;

    @FXML
    private Label pictureError;

    @FXML
    private Label priceError;

    @FXML
    private Slider priceSlider;

    @FXML
    private DatePicker purchaseDatePicker;

    @FXML
    private Label quantityError;

    @FXML
    private Spinner<Integer> quantitySpinner;
    SpinnerValueFactory<Integer> spinValue = new SpinnerValueFactory.IntegerSpinnerValueFactory(-100, 500, 1);

    @FXML
    private ComboBox<String> sizeComboBox;

    @FXML
    private Label sizeError;

    @FXML
    private Label priceValueLabel;

    @FXML
    private Label txtFile;

    @FXML
    void saveEvent(ActionEvent event) {

        String dressName = dressNameField.getText();
        if (dressName.isEmpty()) {
            dressNameError.setText("Dress name is required");
        } else {
            dressNameError.setText("");
        }

        String dressType = dressTypeChoiceBox.getValue();
        if (dressType == null) {
            dressTypeError.setText("Dress type is required");
        } else {
            dressTypeError.setText("");
        }

        String dressSize = sizeComboBox.getValue();
        if (dressSize == null) {
            sizeError.setText("Dress size is required");
        } else {
            sizeError.setText("");
        }

        String dressColor = dressColorPicker.getValue() != null ? dressColorPicker.getValue().toString() : "";
        if (dressColor.isEmpty()) {
            colorError.setText("Dress color is required");
        } else {
            colorError.setText("");
        }

        double sliderValue = priceSlider.getValue();
        if (sliderValue < 500) {
            priceError.setText("Price can't be less than 500");
        } else {
            priceError.setText("");
        }

        String dressDetails = dressTextArea.getText();
        if (dressDetails.length() > 50) {
            detailsError.setText("Only 50 characters is allowed");
        } else {
            detailsError.setText("");
        }

        LocalDate purchaseDate = purchaseDatePicker.getValue();
        if (purchaseDate == null) {
            dateError.setText("Date must be selected");
        } else if (purchaseDate.isAfter(LocalDate.now())) {
            dateError.setText("Date can't be future date");
        } else {
            dateError.setText("");
        }

        int quantity = quantitySpinner.getValue();
        if (quantity < 1) {
            quantityError.setText("Quantity can't be less than 0");
        } else {
            quantityError.setText("");
        }

        String discount = discountField.getText();
        if (!discount.isEmpty()) {
            if (usedDiscounts.contains(discount)) {
                codeError.setText("Same codes already exists.");
                codeError.setVisible(true);
            } else {
                codeError.setVisible(false);
                usedDiscounts.add(discount);
            }
        } else {
            codeError.setVisible(false);
        }

        RadioButton selectedGender = (RadioButton) genderGroup.getSelectedToggle();
        String gender = null;
        if (selectedGender == null) {
            customerError.setText("Targeted customer is required");
        } else {
            gender = selectedGender.getText();
            customerError.setText("");
        }

        boolean agree = agreeCheckBox.isSelected();

        if (!isImageUploaded) {
            pictureError.setText("Picture is required");
        } else {
            pictureError.setText("");
        }

        // Final validation check before saving
        if (!dressNameError.getText().isEmpty() ||
                !dressTypeError.getText().isEmpty() ||
                !sizeError.getText().isEmpty() ||
                !colorError.getText().isEmpty() ||
                !priceError.getText().isEmpty() ||
                !detailsError.getText().isEmpty() ||
                !dateError.getText().isEmpty() ||
                !quantityError.getText().isEmpty() ||
                !customerError.getText().isEmpty() ||
                !pictureError.getText().isEmpty() ||
                codeError.isVisible()) {

            System.out.println("Form has errors. Data not saved.");
            return;
        }


        String line = dressName + ", " + dressType + ", " + dressSize + ", " + dressColor + ", " + sliderValue + ", "
                + dressDetails + ", " + purchaseDate + ", " + quantity + ", " + discount + ", " + gender + ", " + agree + ", " + lastUploadedImagePath + "\n";

        try (Connection conn = ConnectionSingleton.getConnection()) {
            String sql = "INSERT INTO dress (name, type, size, color, price, details, purchase_date, quantity, coupon, customer, boosted, image_path) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            try (java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, dressName);
                stmt.setString(2, dressType);
                stmt.setString(3, dressSize);
                stmt.setString(4, dressColor);
                stmt.setDouble(5, sliderValue);
                stmt.setString(6, dressDetails);
                stmt.setDate(7, java.sql.Date.valueOf(purchaseDate));
                stmt.setInt(8, quantity);
                stmt.setString(9, discount);
                stmt.setString(10, gender);
                stmt.setBoolean(11, agree);
                stmt.setString(12, lastUploadedImagePath);
                stmt.executeUpdate();
            }
            txtFile.setText("Dress saved to MySQL database.");
        } catch (Exception e) {
            e.printStackTrace();
            txtFile.setText("Error saving to database.");
        }



//        try {
//            RandomAccessFile raf = new RandomAccessFile("dress.txt", "rw");
//            raf.seek(raf.length());
//            raf.writeBytes(line);
//            raf.close();
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

        DetailsTable detailsTable = new DetailsTable(dressName, dressType, dressColor, sliderValue, purchaseDate, quantity, agree, dressSize,
                dressDetails, gender, discount, lastUploadedImagePath);
        globalData.detailsTableObservableList.add(detailsTable);

        System.out.println("Dressname is: " + dressName + "\nDresstype is: " + dressType + "\nDress size is: " + dressSize + "\nDress color is: "
                + dressColor + "\nSlider value is: " + sliderValue + "\nDress details: " + dressDetails + "\nPurchase date is: " + purchaseDate + "\nQuantity is: " + quantity + "\nDiscount is: "
                + discount + "\nCustomer is: " + gender + "\nCheckbox agree?: " + agree);

        // Show confirmation on txtFile
        txtFile.setText("Dress Information Saved in TXT File.");

    }

    @FXML
    void UploadEvent(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose an image");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        File file = fileChooser.showOpenDialog(HelloApplication.stage);
        if (file != null) {
            String imagePath = file.toURI().toString();
            imageView.setImage(new Image(imagePath));
            isImageUploaded = true;
            lastUploadedImagePath = imagePath;
        }
    }

    @FXML
    public void showListEvent(ActionEvent event) {
        System.out.println("Redirect to show list scene.");
        HelloApplication.changeScene("second-scene");
    }

    @FXML
    void dressDiscountAlert(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        // Show price when slider is moving
        priceSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            priceValueLabel.setText("Price: " + String.format("%.0f", newValue));
        });

        ObservableList<String> dressTypeList = FXCollections.observableArrayList();
        dressTypeList.add("Full-Sleeve Shirt");
        dressTypeList.add("T-Shirt");
        dressTypeList.add("Pant");
        dressTypeList.add("Jacket");
        dressTypeList.add("Sweater");
        dressTypeChoiceBox.setItems(dressTypeList);

        ObservableList<String> sizeComboList = FXCollections.observableArrayList();
        sizeComboList.add("L");
        sizeComboList.add("M");
        sizeComboList.add("XL");
        sizeComboList.add("XXL");
        sizeComboList.add("XXXL");
        sizeComboBox.setItems(sizeComboList);

        quantitySpinner.setValueFactory(spinValue);
    }
}

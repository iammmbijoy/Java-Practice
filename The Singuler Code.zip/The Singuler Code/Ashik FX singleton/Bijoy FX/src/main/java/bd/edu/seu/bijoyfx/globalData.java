package bd.edu.seu.bijoyfx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class globalData {
    public static ObservableList<DetailsTable> detailsTableObservableList = FXCollections.observableArrayList();
}
